# DomainSMPCore

DomainSMPCore is a Paper plugin for the Domain sm0 SMP.

## Browser build — GitHub Codespaces

1. Upload/push this folder to a GitHub repository.
2. Open the repository in GitHub.
3. Choose **Code → Codespaces → Create codespace on main**.
4. Wait for the Java 21 environment to finish setting up.
5. The project automatically runs `mvn -q -DskipTests package` after the environment is created.
6. If needed, open the terminal and run:

```bash
mvn -DskipTests package
```

The compiled plugin will be at:

```text
target/DomainSMPCore-0.1.0.jar
```

## Browser build — GitHub Actions

Every push also runs `.github/workflows/build.yml` using Java 21 and Maven. When it succeeds, open the workflow run and download the **DomainSMPCore** artifact.

## Requirements

- Java 21
- Maven
- Paper 1.21.x compatible server
- Optional: Geyser-Spigot, Floodgate, LuckPerms, Vault, PlaceholderAPI

The plugin integrates with optional dependencies when present; it does not bundle or replace them.
