package com.domainsmp.core;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.PluginCommand;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public final class DomainSMPCore extends JavaPlugin implements Listener {
    private final Map<UUID, Location> homes = new HashMap<>();
    private final Map<UUID, UUID> tpaRequests = new HashMap<>();

    @Override
    public void onEnable() {
        saveDefaultConfig();
        Bukkit.getPluginManager().registerEvents(this, this);
        register("domainsmp", new CoreCommand(this));
        register("spawn", new SpawnCommand(this));
        register("sethome", new HomeCommand(this));
        register("home", new HomeCommand(this));
        register("tpa", new TpaCommand(this));
        register("tpaccept", new TpaAcceptCommand(this));

        boolean geyser = Bukkit.getPluginManager().getPlugin("Geyser-Spigot") != null;
        boolean floodgate = Bukkit.getPluginManager().getPlugin("floodgate") != null;
        getLogger().info("DomainSMPCore 0.1.0 enabled.");
        getLogger().info("Geyser detected: " + geyser);
        getLogger().info("Floodgate detected: " + floodgate);
    }

    private void register(String name, CommandExecutor executor) {
        PluginCommand command = getCommand(name);
        if (command != null) command.setExecutor(executor);
    }

    public String msg(String key) {
        String prefix = color(getConfig().getString("messages.prefix", ""));
        String body = color(getConfig().getString("messages." + key, key));
        return prefix + body;
    }

    public String color(String text) {
        return ChatColor.translateAlternateColorCodes('&', text);
    }

    public Map<UUID, Location> homes() { return homes; }
    public Map<UUID, UUID> tpaRequests() { return tpaRequests; }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        tpaRequests.remove(event.getPlayer().getUniqueId());
        tpaRequests.values().removeIf(id -> id.equals(event.getPlayer().getUniqueId()));
    }

    interface CommandExecutor extends org.bukkit.command.CommandExecutor {}

    static final class CoreCommand implements CommandExecutor {
        private final DomainSMPCore plugin;
        CoreCommand(DomainSMPCore plugin) { this.plugin = plugin; }
        public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
            if (!sender.hasPermission("domainsmp.admin")) { sender.sendMessage(plugin.msg("no-permission")); return true; }
            if (args.length == 1 && args[0].equalsIgnoreCase("reload")) {
                plugin.reloadConfig(); sender.sendMessage(plugin.color("&aDomainSMPCore reloaded.")); return true;
            }
            if (args.length == 1 && args[0].equalsIgnoreCase("status")) {
                boolean geyser = Bukkit.getPluginManager().getPlugin("Geyser-Spigot") != null;
                boolean floodgate = Bukkit.getPluginManager().getPlugin("floodgate") != null;
                sender.sendMessage(plugin.color("&bDomainSMPCore &7v0.1.0"));
                sender.sendMessage(plugin.color("&7Geyser: " + (geyser ? "&aONLINE" : "&cNOT FOUND")));
                sender.sendMessage(plugin.color("&7Floodgate: " + (floodgate ? "&aONLINE" : "&cNOT FOUND")));
                return true;
            }
            sender.sendMessage(plugin.color("&eUse: /domainsmp <reload|status>"));
            return true;
        }
    }

    static final class SpawnCommand implements CommandExecutor {
        private final DomainSMPCore plugin;
        SpawnCommand(DomainSMPCore plugin) { this.plugin = plugin; }
        public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
            if (!(sender instanceof Player player)) return true;
            player.teleport(player.getWorld().getSpawnLocation());
            player.sendMessage(plugin.msg("spawn-teleport"));
            return true;
        }
    }

    static final class HomeCommand implements CommandExecutor {
        private final DomainSMPCore plugin;
        HomeCommand(DomainSMPCore plugin) { this.plugin = plugin; }
        public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
            if (!(sender instanceof Player player)) return true;
            if (label.equalsIgnoreCase("sethome")) {
                plugin.homes().put(player.getUniqueId(), player.getLocation().clone());
                player.sendMessage(plugin.msg("home-set"));
                return true;
            }
            Location home = plugin.homes().get(player.getUniqueId());
            if (home == null) { player.sendMessage(plugin.msg("no-home")); return true; }
            player.teleport(home);
            player.sendMessage(plugin.msg("home-teleport"));
            return true;
        }
    }

    static final class TpaCommand implements CommandExecutor {
        private final DomainSMPCore plugin;
        TpaCommand(DomainSMPCore plugin) { this.plugin = plugin; }
        public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
            if (!(sender instanceof Player player) || args.length != 1) return true;
            Player target = Bukkit.getPlayerExact(args[0]);
            if (target == null || target.equals(player)) { player.sendMessage(plugin.color("&cPlayer not found.")); return true; }
            plugin.tpaRequests().put(target.getUniqueId(), player.getUniqueId());
            player.sendMessage(plugin.msg("tpa-sent").replace("{player}", target.getName()));
            target.sendMessage(plugin.msg("tpa-received").replace("{player}", player.getName()));
            Bukkit.getScheduler().runTaskLater(plugin, () -> {
                UUID requester = plugin.tpaRequests().get(target.getUniqueId());
                if (player.getUniqueId().equals(requester)) {
                    plugin.tpaRequests().remove(target.getUniqueId());
                    if (player.isOnline()) player.sendMessage(plugin.msg("tpa-expired"));
                }
            }, 20L * 60);
            return true;
        }
    }

    static final class TpaAcceptCommand implements CommandExecutor {
        private final DomainSMPCore plugin;
        TpaAcceptCommand(DomainSMPCore plugin) { this.plugin = plugin; }
        public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
            if (!(sender instanceof Player target)) return true;
            UUID requesterId = plugin.tpaRequests().remove(target.getUniqueId());
            if (requesterId == null) { target.sendMessage(plugin.color("&cNo pending teleport request.")); return true; }
            Player requester = Bukkit.getPlayer(requesterId);
            if (requester == null) { target.sendMessage(plugin.color("&cThe requester is offline.")); return true; }
            requester.teleport(target.getLocation());
            target.sendMessage(plugin.msg("tpa-accepted"));
            requester.sendMessage(plugin.msg("tpa-accepted"));
            return true;
        }
    }
}
